using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Configuration;

namespace JBA_Challenge
{
    public partial class Form1 : Form
    {        
        SqlCommand command;
        string file, gridBlock;
        string[] xYRef;
        int header = 5;
        int blockSkip = 5;
        int xRef = 0; 
        int yRef = 0;
        long lineSize = 0;
        List<int> valueList = new List<int>();
        

        public Form1()
        {
            InitializeComponent();

            
        }

        private void Add_JBA_Data_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void AddFileButton_Click(object sender, EventArgs e)
        {
            readFile();
            getLineCount(file);
            richTextBox1.Text = displayHeader(file);   
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void saveToDatabaseButton_Click(object sender, EventArgs e)
        {
            do
            {
                gridBlock = setGridBlock(file, blockSkip);

                xYRef = getGridRef(gridBlock);

                xRef = getXRef(xYRef);

                yRef = getYRef(xYRef);

                getValueList(gridBlock);

                addToDatabase(xRef, yRef, valueList);

                blockSkip += 11;
                gridBlock = "";
                Array.Clear(xYRef, 0, xYRef.Length);
                xRef = 0;
                yRef = 0;
                valueList.Clear();

            } while (blockSkip < lineSize);

            MessageBox.Show("Data Added");
        }

        public string readFile()
        {
            DialogResult result = Add_JBA_Data.ShowDialog();
            file = Add_JBA_Data.FileName;
            return file;

        }

        public long getLineCount(string file)
        {
            lineSize = File.ReadLines(file).Count();
            return lineSize;
        }

        public string displayHeader(string file)
        {
            var headerLines = string.Join("\r\n", File.ReadLines(file).Take(header));

            return headerLines;
        }

        public string setGridBlock(string file, int blockSkip)
        {
            string gridBlock = null;
            try
            {
                gridBlock = string.Join("\r\n", File.ReadLines(file).Skip(blockSkip).Take(11));
            }
            catch (System.OutOfMemoryException)
            {

            }
            return gridBlock;
        }
        
        public string[] getGridRef(string gridBlock)
        {
            StringReader stringReader = new StringReader(gridBlock);
            string firstLine = stringReader.ReadLine();
            string xYRef = firstLine.Replace("Grid-ref= ", "");
            string[] splitRef = xYRef.Split(',');
            return splitRef;
        }

        public int getXRef(string[] xYRef)
        {
            return Int32.Parse(xYRef[0]);
        }

        public int getYRef(string[] xYRef)
        {
            return Int32.Parse(xYRef[1]);
        }

        public List<int> getValueList(string gridBlock)
        {
            List<string> values = new List<string>();
            string[] lines = gridBlock.Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray();

            for (int i = 0; i < lines.Length; ++i)
            {
                string value = lines[i];
                string[] rainfallArray = value.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                for (int j = 0; j < rainfallArray.Length; ++j)
                {
                    values.Add(rainfallArray[j]);
                }
            }

            valueList = values.ConvertAll(int.Parse);
            return valueList;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void addToDatabase(int xRef, int yRef, List<int> valueList)
        {
            string connectString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectString);
            string query = "INSERT INTO rainfallData (xRef, yRef, date, value) Values (@inputX, @inputY, @inputDate, @inputValue)";
            DateTime date = new DateTime(1991, 1, 1);
            int value = 0;

            for (int i = 0; i < valueList.Count; i++)
            {
                value = valueList[i];

                using (command = new SqlCommand(query,connection))
                {
                    command.Parameters.AddWithValue("@inputX", xRef);
                    command.Parameters.AddWithValue("@inputY", yRef);
                    command.Parameters.AddWithValue("@inputDate", date);
                    command.Parameters.AddWithValue("@inputValue", value);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                }                
                date = date.AddMonths(1);              
            }   
        }
    }
}
